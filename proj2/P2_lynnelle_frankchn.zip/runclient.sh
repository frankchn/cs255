#!/bin/bash
java mitm.MITMAdminClient -password cs255password -cmd stats