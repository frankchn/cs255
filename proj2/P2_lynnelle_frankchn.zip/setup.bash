#!/bin/bash

export CLASSPATH="${CLASSPATH}:.:iaik_jce.jar"
